﻿using Microsoft.EntityFrameworkCore;
using ProductManagementSystem.Models;

namespace ProductManagementSystem.DataContext
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) 
        {
        
        
        }
        public DbSet<CatagoryInfo> Catagories { get;set; }
        
        public DbSet<ProductInfo> Products { get; set; }
    }
}
