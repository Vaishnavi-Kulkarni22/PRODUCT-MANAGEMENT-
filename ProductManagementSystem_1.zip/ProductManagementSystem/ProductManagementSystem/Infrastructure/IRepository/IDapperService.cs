﻿
using Dapper;
using System.Data;

namespace ProductManagementSystem.Infrastructure.IRepository
{
    public interface IDapperService:IDisposable
    {
        T Get<T>(string sp, DynamicParameters parms, CommandType 
            commandType = CommandType.StoredProcedure);

        List<T> GetAll<T>(string sp, DynamicParameters parms, CommandType
            commandType = CommandType.StoredProcedure);

        int AddProduct<T>(string sp, DynamicParameters parms, CommandType
            commandType = CommandType.StoredProcedure);
    }

}
