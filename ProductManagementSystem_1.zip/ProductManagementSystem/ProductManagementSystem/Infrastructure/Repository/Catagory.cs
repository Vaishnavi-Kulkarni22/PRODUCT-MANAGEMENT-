﻿using Dapper;
using ProductManagementSystem.Infrastructure.IRepository;
using ProductManagementSystem.Models;
using System.Data;

namespace ProductManagementSystem.Infrastructure.Repository
{
    public class Catagory : ICatagory
    {
        private readonly IDapperService _dapper;

        public Catagory(IDapperService dapper)
        {
            _dapper = dapper;
        }

        public CatagoryInfo AddCatagory(CatagoryInfo catagoryInfo)
        {
           
            CatagoryInfo model = new CatagoryInfo();
            try
            {
                var dbPara = new DynamicParameters();
                dbPara.Add("@Catagory_Id", catagoryInfo.Category_Id);
                dbPara.Add("CategoryTitle", catagoryInfo.CategoryTitle);
                dbPara.Add("GroupName", catagoryInfo.GroupName);
                dbPara.Add("CategoryStatus", catagoryInfo.CategoryStatus);
                catagoryInfo.TotalRowCount = Task.FromResult(_dapper.AddProduct<CatagoryInfo>("CategoryAddEdit", dbPara, commandType: CommandType.StoredProcedure)).Result;
            }
            catch (Exception)
            {

                throw;
            }
            return model;

        }

        public CatagoryInfo DeleteCatagory(CatagoryInfo infomodel)
        {

            CatagoryInfo model = new CatagoryInfo();
            try
            {
                var dbPara = new DynamicParameters();
                dbPara.Add("@Catagory_Id", infomodel.Category_Id);

                model.TotalRowCount = Task.FromResult(_dapper.AddProduct<CatagoryInfo>("CategoryDelete", dbPara, commandType: CommandType.StoredProcedure)).Result;
            }
            catch (Exception)
            {

                throw;
            }
            return model;
        }

        public CatagoryInfo GetCategoryById(int id)
        {
            var query = @"SELECT * FROM Catagory where Catagory_Id=@Catagory_Id";
            CatagoryInfo catagoryInfo = new CatagoryInfo();
            try
            {
                var dbPara = new DynamicParameters();
                dbPara.Add("Category_Id", id);
                catagoryInfo = Task.FromResult(_dapper.Get<CatagoryInfo>(query, dbPara, commandType: CommandType.Text)).Result;
            }
            catch (Exception)
            {

                throw;
            }
            return catagoryInfo;
        }

        public List<CatagoryInfo> GetCategoryData()
        {
            var query = @"SELECT * FROM Category";
            List<CatagoryInfo> catagories = new List<CatagoryInfo>();
            try
            {
                catagories = Task.FromResult(_dapper.GetAll<CatagoryInfo>(query, null, commandType: CommandType.Text)).Result;
            }
            catch (Exception)
            {

                throw;
            }
            return catagories;
        }

        //public CatagoryInfo UpdateCatagory(CatagoryInfo catagoryInfo)
        //{

        //    CatagoryInfo model = new CatagoryInfo();
        //    try
        //    {
        //        var dbPara = new DynamicParameters();
        //        dbPara.Add("@Catagory_Id", catagoryInfo.Category_Id);
        //        dbPara.Add("CategoryTitle", catagoryInfo.CategoryTitle);
        //        dbPara.Add("GroupName", catagoryInfo.GroupName);
        //        dbPara.Add("CategoryStatus", catagoryInfo.CategoryStatus);
        //        catagoryInfo.TotalRowCount = Task.FromResult(_dapper.AddProduct<CatagoryInfo>("CategoryAddEdit", dbPara, commandType: CommandType.StoredProcedure)).Result;
        //    }
        //    catch (Exception)
        //    {

        //        throw;
        //    }
        //    return model;
        //}
    }
}
