﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ProductManagementSystem.Infrastructure.IRepository;
using ProductManagementSystem.Models;
using System.Reflection.Metadata.Ecma335;

namespace ProductManagementSystem.Controllers
{
    public class CatagoryController : Controller
    {
        private readonly ICatagory _services;

        public CatagoryController(ICatagory services)
        {

            _services = services;
        }

        // GET: CatagoryController
        public ActionResult Index()
        {
            CatagoryInfoModel model = new CatagoryInfoModel();
            model.CategoriesList = _services.GetCategoryData();
            return View(model);
        }

        // GET: CatagoryController/Details/5
        public ActionResult Details(int id)
        {
            CatagoryInfo model = new CatagoryInfo();
            model=_services.GetCategoryById(id);
            return View(model);
        }

        [HttpGet]
        public ActionResult AddEditCatrgory(int id)
        {
            CatagoryInfo model = new CatagoryInfo();
            model=_services.GetCategoryById(id);
            if (model==null)
            {
                return View();
            }
            else
            {

            return View(model);
            }
        }

        // POST: CatagoryController/Create
       
        [HttpPost]
        public ActionResult Create(CatagoryInfo infomodel)
        {
            CatagoryInfo model = new CatagoryInfo();
            try
            {
                    model=_services.AddCatagory(infomodel);
                if(model.TotalRowCount>0)
                {
                return RedirectToAction(nameof(Index));

                }
                else
                {
                    return NotFound();
                }
            }
            catch
            {
                return View();
            }
        }
       

        // POST: CatagoryController/Delete/5
        [HttpPost]
       
        public ActionResult Delete(CatagoryInfo infomodel)
        {
            CatagoryInfo model = new CatagoryInfo();
            try
            {
                model = _services.DeleteCatagory(infomodel);
                if (model.TotalRowCount > 0)
                {
                    return RedirectToAction(nameof(Index));

                }
                else
                {
                    return NotFound();
                }
            }
            catch
            {
                return View();
            }
        }
    }
}
