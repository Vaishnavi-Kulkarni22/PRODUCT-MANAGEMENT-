﻿using Dapper;
using Microsoft.Data.SqlClient;
using ProductManagementSystem.Infrastructure.IRepository;
using System.Data;
using System.Security.AccessControl;

namespace ProductManagementSystem.Infrastructure.Repository
{
    public class DapperService : IDapperService
    {
        private readonly IConfiguration _config;
        private string ConnnectionString = "DefaultConnection";

        public DapperService(IConfiguration config)
        {
            _config = config;
        }

        public int AddProduct<T>(string sp, DynamicParameters parms, CommandType commandType = CommandType.StoredProcedure)
        {
            IDbConnection db = new SqlConnection(_config.GetConnectionString(ConnnectionString));
            return db.Execute(sp, parms, commandType:commandType);
        }

        public void Dispose()
        {
            throw new NotImplementedException();
        }

        public T Get<T>(string sp, DynamicParameters parms, CommandType commandType = CommandType.StoredProcedure)
        {
            IDbConnection db = new SqlConnection(_config.GetConnectionString(ConnnectionString));
            return db.Query(sp, parms, commandType: commandType).FirstOrDefault();
        }

        public List<T> GetAll<T>(string sp, DynamicParameters parms, CommandType commandType = CommandType.StoredProcedure)
        {
            IDbConnection db = new SqlConnection(_config.GetConnectionString(ConnnectionString));
            return db.Query<T>(sp, parms, commandType: commandType).ToList();
        }
    }
}
