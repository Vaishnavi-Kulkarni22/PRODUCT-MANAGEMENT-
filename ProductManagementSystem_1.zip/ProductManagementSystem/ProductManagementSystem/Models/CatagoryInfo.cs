﻿ namespace ProductManagementSystem.Models
{
    public class CatagoryInfo
    {
        public int Category_Id { get; set; }

        public string? CategoryTitle { get; set; }

        public string? GroupName { get; set; }

        public DateTime CreationDate { get; set; }

        public int CategoryStatus { get; set; }

        public int TotalRowCount { get; set; }
    }

    public class CatagoryInfoModel
    {
    
        private List<CatagoryInfo> _categories = new List<CatagoryInfo>();
        public List<CatagoryInfo> CategoriesList
        {
            get { return _categories; }
            set { _categories = value; }
        }
    }
}
