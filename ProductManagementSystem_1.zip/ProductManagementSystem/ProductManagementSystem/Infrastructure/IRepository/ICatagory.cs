﻿using ProductManagementSystem.Models;

namespace ProductManagementSystem.Infrastructure.IRepository
{
    public interface ICatagory
    {
        List<CatagoryInfo> GetCategoryData();
        CatagoryInfo GetCategoryById(int id);
        CatagoryInfo AddCatagory(CatagoryInfo catagoryInfo);
       // CatagoryInfo UpdateCatagory(CatagoryInfo catagoryInfo);
        CatagoryInfo DeleteCatagory(CatagoryInfo infomodel);
    }
}
